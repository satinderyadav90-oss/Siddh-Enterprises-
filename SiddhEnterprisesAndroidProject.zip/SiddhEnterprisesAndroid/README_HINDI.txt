SIDDH ENTERPRISES — ANDROID APP PROJECT

यह Android Studio project है, तैयार APK नहीं। इसे compile करके APK बनाने के लिए Android Studio और Android SDK की जरूरत होगी। इस environment में Android SDK/Gradle उपलब्ध नहीं है, इसलिए APK compile नहीं किया जा सका।

ऐप में शामिल:
- Native Android launcher activity (ऐप आइकन से खुलेगी; Chrome खोलने की जरूरत नहीं)
- ऑफलाइन HTML app bundled inside Android app
- रोज़ की income/expense entry और contract summary
- local browser storage (WebView local storage)
- CSV export
- Hindi/English toggle
- file picker hook for bill attachment selection (इस prototype में file contents सुरक्षित रूप से archive नहीं होते; केवल file name दर्ज होता है)

APK बनाने के चरण:
1. Android Studio install करें।
2. इस folder को Android Studio में Open करें।
3. Gradle sync पूरा होने दें और Android SDK 35 install करें यदि पूछा जाए।
4. Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
5. APK आम तौर पर app/build/outputs/apk/debug/app-debug.apk में बनेगा।
6. APK अपने Android phone में भेजकर install करें। Unknown-app installation की अनुमति Android Settings में देनी पड़ सकती है।

महत्वपूर्ण सीमाएँ:
- यह प्रारंभिक हिसाब prototype है, पूर्ण accounting/tax software नहीं।
- डेटा इसी डिवाइस के ऐप में रहता है; cloud sync और सुरक्षित remote backup नहीं हैं।
- ऐप data clear/uninstall होने पर डेटा मिट सकता है। CSV रिपोर्ट नियमित export करके सुरक्षित रखें।
- सरकारी ठेकों के आधिकारिक GST/TDS/retention/accounting records की पुष्टि accountant से करें।
